const express = require('express');
//morgan pour les logs d'erreurs 500
const morgan = require('morgan');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const tachesRoutes = require('./src/routes/taches.routes');

const app = express();
const PORT = process.env.PORT || 3000;

const errorLogStream = fs.createWriteStream(path.join(__dirname, 'logs', 'error.log'), { flags: 'a' });

// Morgan log uniquement les erreurs 500
app.use(morgan((tokens, req, res) => {
  if (res.statusCode >= 500) {
    return [
      tokens.method(req, res),
      tokens.url(req, res),
      tokens.status(req, res),
      '-',
      tokens['response-time'](req, res), 'ms'
    ].join(' ');
  }
}, { stream: errorLogStream }));

app.use(express.json());
app.use('/taches', tachesRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erreur: 'Erreur interne du serveur' });
});

app.listen(PORT, () => {
  console.log(`Serveur à l'écoute sur le port ${PORT}`);
});


/*
1) Hasher les mots de passe
2) OK  Faire en sorte que tout ce qui touche au tâche le soit par l'utilisateur même (Need?)
3) Faire tous les tests POSTMAN
4) Faire les logs d'erreurs 500 dans un fichier.
5) Interface de gesƟon des uƟlisateurs
- Vous devez créer une page HTML avec un script JavaScript qui fournit une interface
permeƩant de :
o Créer un nouvel uƟlisateur
o Récupérer ou régénérer une nouvelle clé api.
- UƟlisez la foncƟon Fetch en JavaScript pour interagir avec les deux routes de gesƟon des
uƟlisateurs de votre api.
- Vous trouverez à l’annexe B un « wireframe » de la page à créer. Vous devez vous le
reproduire le plus fidèlement possible.
5)Doc (DO I even have time!?!?)

*/
